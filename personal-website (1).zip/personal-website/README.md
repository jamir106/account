# Personal Website

A Pen created on CodePen.

Original URL: [https://codepen.io/Online-Zone/pen/EaVayyg](https://codepen.io/Online-Zone/pen/EaVayyg).

A one-page web page about yourself and your socials is commonly known as a "personal website" or a "personal landing page." It serves as a digital hub to showcase your personal brand, share information about yourself, and provide links to your social media profiles and other online platforms. This type of website is often used by individuals, professionals, creatives, and influencers to present a concise overview of their online presence.